package employeeSystem;

public class SalariedEmployee extends Employee{
/** the amount this Employee gets paide very period*/
	/**
	 * @param firstName
	 * @param lastName
	 * @param eid
	 * @param salary
	 */
	protected double salary
	public SalariedEmplyee(String firstName, String lastName, String eid, double salary) {
		super(firstName, lastName, eid);
	}
}
